You can copy here your custom .sh, .sql or .sql.gz file so they are executed during the first boot of the image.

More info in the [bitnami-docker-mariadb](https://github.com/bitnami/bitnami-docker-mariadb#initializing-a-new-instance) repository.